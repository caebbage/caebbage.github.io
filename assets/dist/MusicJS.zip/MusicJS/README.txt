Music.js is a jQuery script created by cae (http://caebbage.github.io), designed to allow the stylization of the music player.

This script is released under the Attribution-NonCommercial-ShareAlike license.
https://creativecommons.org/licenses/by-nc-sa/4.0/

The icons in the base script is from Font Awesome.
http://fontawesome.io/

(Note: sorry for bad formatting of this document. I'm a noob.)


---------------------------------------------


Included files:
  music.js
  // This is the original script.
  music.notime.js
  // This is a modified version without timestamps.
  music.nobar.js
  // This is a modified version without the scrub bar.
  music.btnonly.js
  // This is a modified version without the timestamp nor scrub bar.
  music.css
  // A sheet including the styling of the music player.


---------------------------------------------


Usage:
After inserting the script and CSS into your web page's header, insert this for each music player:

<div class="music"><audio src="AUDIO FILE" /></div>

Removing the <div> will disable the formatting.


---------------------------------------------


Below are the classes of note within the music player's structure.

  .controls (REQUIRED)
  // This class holds the play, pause, pause, and error buttons.

(scrubber classes)
  .scrubber (REQUIRED FOR COMPONENT)
  // The container of the scrubber. 
  .progress (REQUIRED FOR COMPONENT)
  // The thing inside the scrubber that shows progress. Removing this removes the purpose of the scrubber altogether.
  .scrub
  // This is the little button/thumb circle to let you adjust the time. Removing this disallows the ability to drag to the desired time.

(timestamp classes)
  .curr
  // The current timestamp.
  .full
  // The max duration.