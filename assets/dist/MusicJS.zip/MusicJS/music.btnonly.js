/*  Created by http://caebbage.github.io, please do not remove credits.

    This work is licensed under a Creative Commons
    Attribution-NonCommercial-ShareAlike 4.0 International License.
        https://creativecommons.org/licenses/by-nc-sa/4.0                 */

var structure = '<div class="controls"><i class="play fa fa-play-circle-o fa-fw"></i><i class="pause fa fa-pause-circle-o fa-fw"></i><i class="load fa fa-refresh fa-spin fa-fw"></i><i class="error fa fa-exclamation-triangle fa-fw"></i></div></div>';

var musicjs = function() {
  $(".music").each(function(i, ele) {
    $(ele).prepend(structure);
    var contr =$(ele).find(".controls");
    var audio = $(ele).find('audio');
    var max = 0;
    var playing = false;

    contr.addClass("loading");

    audio.ready(function() {contr.removeClass("loading").addClass("paused");})
	.on("canplay", function() {max = this.duration;})
	.on("error", function() {contr.removeClass().addClass('controls error');});

    contr.click(function() {
      if ($(this).hasClass("error")) {
        return; // if you are an error, fuck off
      } if ($(this).hasClass("paused")) {
        $(this).removeClass('paused').addClass('playing');
        audio.trigger("play");
        playing = true;
      } else if ($(this).hasClass("playing")) {
        $(this).removeClass('playing').addClass('paused');
        audio.trigger("pause");
        playing = false;
      }
    });
  });
}

$(document).ready(function() {musicjs();});
